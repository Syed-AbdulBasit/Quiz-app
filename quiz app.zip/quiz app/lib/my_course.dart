import 'package:flutter/material.dart';

import 'main.dart';



class Course extends StatefulWidget {
  @override
  _Course createState() => _Course();
}

class _Course extends State<Course> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
          appBar: AppBar(
            title: Text('Courses'),
          ),
        floatingActionButtonLocation: FloatingActionButtonLocation.endDocked,
        floatingActionButton: FloatingActionButton(
          // isExtended: true,
            child: Icon(Icons.home),
            backgroundColor: Colors.white,
            onPressed: () {
               SplashScreen();
            }),
          body: ListView(children: <Widget>[
            Center(
                child: Text(
                  'COURSES',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                )),
            DataTable(
              columns: [
                DataColumn(label: Text('No')),
                DataColumn(label: Text('Name')),
                DataColumn(label: Text('Instructor')),
              ],
              rows: [
                DataRow(cells: [
                  DataCell(Text('1')),
                  DataCell(Text('Mobile Application Development')),
                  DataCell(Text('Sir Muhammad Abdullah ')),
                ]),
                DataRow(cells: [
                  DataCell(Text('2')),
                  DataCell(Text('Web Technologies')),
                  DataCell(Text('Sir Yasir Muneer')),
                ]),
                DataRow(cells: [
                  DataCell(Text('3')),
                  DataCell(Text('Human Computer Interaction')),
                  DataCell(Text('Sir Uzair Ishtiaq')),
                ]),
                DataRow(cells: [
                  DataCell(Text('4')),
                  DataCell(Text('Data Comunication and Computer Networks')),
                  DataCell(Text('Sir Muhammad Mudassar')),
                ]),
                DataRow(cells: [
                  DataCell(Text('5')),
                  DataCell(Text('Microprocessor and Assembly Language')),
                  DataCell(Text('Sir Rao Tauif')),
                ]),
                DataRow(cells: [
                  DataCell(Text('6')),
                  DataCell(Text('Pakistan Studies')),
                  DataCell(Text('Maam Aqsa azfar')),
                ]),
              ],
            ),
          ])),
    );
  }
}